
import { Link } from "react-router-dom";
import React, { useState } from 'react';


function Authlayout() {
                     
    return (
        
        <>
          

            


        </>
    );
}

export default Authlayout;
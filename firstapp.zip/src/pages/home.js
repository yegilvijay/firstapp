
import { Link } from "react-router-dom";
import React, { useState } from 'react';
import TopHaeder from "../component/header";

function Home() {
  
                 
    return (
        
        <>
        
            <h1>welcome</h1>
        </>
    );
}

export default Home;
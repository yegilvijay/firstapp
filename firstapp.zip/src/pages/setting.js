

import React, { useState } from 'react';

function Settings() {
   
             
    return (
        
        <>
      
      <h2>Setting</h2>

        
            
          

           


        </>
    );
}

export default Settings;